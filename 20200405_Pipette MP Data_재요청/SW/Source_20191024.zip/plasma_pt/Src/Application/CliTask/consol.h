#ifndef CONSOL_H
#define CONSOL_H

void vStartCONSOLTasks( void );

#endif

